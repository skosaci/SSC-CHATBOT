import "dotenv/config";
import express from "express";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const { ANTHROPIC_API_KEY, CLAUDE_MODEL = "claude-sonnet-5-5", PORT = 3000 } = process.env;
if (!ANTHROPIC_API_KEY) { console.error("Missing ANTHROPIC_API_KEY in .env"); process.exit(1); }

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "50kb" }));
app.use(express.static(path.join(__dirname, "public")));

// Prompt + knowledge base are re-read on every request,
// so SSC staff can edit knowledge/ssc.json without restarting the server.
function buildSystemPrompt() {
  const rules = fs.readFileSync(path.join(__dirname, "knowledge/system-prompt.md"), "utf8");
  const kb = fs.readFileSync(path.join(__dirname, "knowledge/ssc.json"), "utf8");
  return `${rules}\n\n<ssc_knowledge_base>\n${kb}\n</ssc_knowledge_base>`;
}

// Simple in-memory rate limit: 20 requests / minute / IP
const hits = new Map();
function limited(ip) {
  const now = Date.now(), h = hits.get(ip);
  if (!h || now > h.reset) { hits.set(ip, { n: 1, reset: now + 60_000 }); return false; }
  return ++h.n > 20;
}

app.post("/api/chat", async (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: "rate_limited" });

  let msgs = Array.isArray(req.body?.messages) ? req.body.messages : [];
  msgs = msgs
    .filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
    .map(m => ({ role: m.role, content: m.content.slice(0, 2000) }))
    .slice(-20);
  while (msgs.length && msgs[0].role !== "user") msgs.shift();
  if (!msgs.length || msgs.at(-1).role !== "user") return res.status(400).json({ error: "bad_request" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: CLAUDE_MODEL, max_tokens: 800, system: buildSystemPrompt(), messages: msgs })
    });
    if (!r.ok) { console.error("Anthropic API", r.status, await r.text()); return res.status(502).json({ error: "upstream" }); }
    const data = await r.json();
    const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
    res.json({ reply });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "server" });
  }
});

app.get("/health", (_, res) => res.send("ok"));
app.listen(PORT, () => console.log(`SSC chatbot running on http://localhost:${PORT}`));
