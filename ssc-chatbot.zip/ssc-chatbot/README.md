# Ask SSC – Student Success Center Chatbot

Yapı: `public/index.html` (arayüz) → `server.js` (Express backend) → Claude API.
API anahtarı sadece sunucuda `.env` içinde durur, tarayıcıya hiç gitmez.

## Yerelde çalıştırma
1. Node.js 18+ kurun.
2. `npm install`
3. `.env.example` dosyasını `.env` olarak kopyalayın, `ANTHROPIC_API_KEY` değerini yazın (console.anthropic.com).
4. `npm start` → http://localhost:3000

## Bilgi bankasını güncelleme
`knowledge/ssc.json` dosyasını düzenleyin; sunucuyu yeniden başlatmanız gerekmez.
`not_yet_verified` altındaki konuları SSC'den doğruladıktan sonra `verified` bölümüne taşıyın.
Bot, doğrulanmamış konularda uydurmak yerine öğrenciyi resmi sayfaya yönlendirir.
Davranış kuralları: `knowledge/system-prompt.md`.

## Yayına alma (örn. Render / Railway)
1. Klasörü bir GitHub deposuna yükleyin (`.env` yüklenmez, `.gitignore` engeller).
2. Render'da "New Web Service" → depoyu seçin. Build: `npm install`, Start: `npm start`.
3. Environment Variables bölümüne `ANTHROPIC_API_KEY` (ve isterseniz `CLAUDE_MODEL`) ekleyin.
4. Verilen https adresini SSC sitesine ekleyin:
   `<iframe src="https://SIZIN-ADRES.onrender.com" style="position:fixed;inset:0;width:100%;height:100%;border:0;pointer-events:none" title="Ask SSC"></iframe>`
   (Daha sade yöntem: sitede ayrı bir "Ask SSC" sayfası verip bu adrese bağlantı vermek.)

## Güvenlik ve maliyet
- IP başına dakikada 20 istek sınırı, mesaj uzunluğu ve geçmiş sınırı vardır.
- Anthropic konsolunda aylık harcama limiti belirlemeniz önerilir.
- Öğrencilerden kişisel veri istemeyin; üniversitenin KVKK sürecine göre bilgilendirme ekleyin.

## Henüz yok
Öğrenci ilerleme takibi (My Learning Progress) veri tabanı gerektirir; bu sürümde yoktur.
